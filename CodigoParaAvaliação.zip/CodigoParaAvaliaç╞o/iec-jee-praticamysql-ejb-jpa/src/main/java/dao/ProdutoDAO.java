package dao;

import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import model.*;

public class ProdutoDAO {
    
    public String inserir(Produto produto) {	

		String retorno = "falha";
		Conexao conn = new Conexao();
		
        try {
			Statement stmt = (Statement) conn.getConn().createStatement();
			stmt.execute("INSERT INTO produto (nome,valor,categoria_id) VALUES ('"+produto.getNome() + "'," + produto.getValor() + "," + produto.getCategoria_id() + ")");
			retorno = "sucesso";
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			conn.fecharConexao();
		}		
		return retorno;
	}

    public List<Produto> listar(){
		
        List<Produto> produtos = new ArrayList<Produto>();
		Conexao conn = new Conexao();

		try {
			Statement stmt = (Statement) conn.getConn().createStatement();
			ResultSet rs = stmt.executeQuery("SELECT * from produto");
			while (rs.next()) {
				Produto produto = new Produto();
				produto.setCodigo(rs.getInt("codigo"));
				produto.setNome(rs.getString("nome"));
                produto.setValor(rs.getFloat("valor"));
                produto.setCategoria_id(rs.getInt("categoria_id"));
				produtos.add(produto);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			conn.fecharConexao();
		}
		return produtos;
	}
}
