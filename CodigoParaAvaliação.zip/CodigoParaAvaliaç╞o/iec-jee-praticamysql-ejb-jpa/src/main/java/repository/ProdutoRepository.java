package repository;

import java.util.List;

import model.Produto;

public interface ProdutoRepository {
	
    void inserir(Produto produto);
	
    List<Produto> listar();

    List<Produto> listarPorNome(String nome);
    
    void deletar(Integer codigo) throws Exception;

}
