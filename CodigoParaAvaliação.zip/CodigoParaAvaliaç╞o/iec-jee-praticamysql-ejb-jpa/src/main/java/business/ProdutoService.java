package business;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;

import model.Produto;
import repository.ProdutoRepository;
import repository.RepositorySession;

@Stateless
public class ProdutoService {
	
    @EJB
    private RepositorySession repository;
    private ProdutoRepository produtoRepository;

    @PostConstruct
    public void initialize() {
        produtoRepository = repository.getProdutoRepository();
    }

    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public void inserir(Produto timesheet) {
        produtoRepository.inserir(timesheet);
    }

    public List<Produto> listar() {
        return produtoRepository.listar();
    }

   public List<Produto> listarPorNome(String nome) {
       
        return produtoRepository.listarPorNome(nome);
    }

    /*public Categoria porCodigo(Integer codigo) throws Exception {
        return categoriaRepository.porCodigo(codigo);
    }*/

   /* @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public void editar(Categoria categoria) throws Exception {
        categoriaRepository.editar(categoria);
    }*/

    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public void deletar(Integer codigo) throws Exception {
        produtoRepository.deletar(codigo);
    } 

}
